"""MCP Hub tool installer and uninstaller.

This module provides the `Installer` class for managing MCP tool lifecycle:
install, uninstall, update, verify, and list installed tools.
"""

from __future__ import annotations

import hashlib
import ipaddress
import json
import logging
import os
import platform
import re
import shlex
import shutil
import socket
import ssl
import stat
import subprocess
import tarfile
import tempfile
import time
import urllib.error
import urllib.request
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import urlparse

from mcp_hub.constants import (
    DEFAULT_DATA_DIR,
    INSTALL_TYPES,
    InstallationError,
)
from mcp_hub.registry import MCPTool, Registry

logger = logging.getLogger(__name__)


@dataclass
class InstallResult:
    """Result of an install / uninstall / update operation."""

    success: bool
    tool_name: str
    message: str
    install_path: Optional[str] = None
    install_method: Optional[str] = None
    errors: List[str] = field(default_factory=list)


class Installer:
    """Manages MCP tool installation, uninstallation, and verification."""

    # Map shorthand names to the executable checked on PATH
    _PREREQ_COMMANDS: Dict[str, List[str]] = {
        "npm": ["npm", "--version"],
        "pip": ["pip", "--version"],
        "docker": ["docker", "--version"],
        "git": ["git", "--version"],
    }

    # ------------------------------------------------------------------
    # Security constants
    # ------------------------------------------------------------------
    MAX_DOWNLOAD_SIZE: int = 500 * 1024 * 1024  # 500 MB
    DOWNLOAD_TIMEOUT: int = 60  # seconds
    MAX_REDIRECTS: int = 5
    CHUNK_SIZE: int = 8192  # 8 KB

    # ------------------------------------------------------------------
    # Security helpers (class-level, no external state)
    # ------------------------------------------------------------------

    @staticmethod
    def _is_internal_address(host: str) -> bool:
        """Return True if *host* resolves to a private / loopback / link-local / reserved IP."""
        if not host:
            return True  # empty hostname is unsafe

        # Normalise localhost variants
        if host.lower() in ("localhost", "localhost.localdomain"):
            return True

        try:
            # Literal IP address?
            addr = ipaddress.ip_address(host)
            return (
                addr.is_private
                or addr.is_loopback
                or addr.is_link_local
                or addr.is_reserved
                or addr.is_multicast
            )
        except ValueError:
            # Hostname — resolve *all* A/AAAA records and check each one
            try:
                infos = socket.getaddrinfo(host, None)
            except socket.gaierror:
                return True  # unresolvable host treated as internal / unsafe
            for _, _, _, _, sockaddr in infos:
                ip_str = sockaddr[0]
                try:
                    addr = ipaddress.ip_address(ip_str)
                except ValueError:
                    continue
                if (
                    addr.is_private
                    or addr.is_loopback
                    or addr.is_link_local
                    or addr.is_reserved
                    or addr.is_multicast
                ):
                    return True
            return False

    @staticmethod
    def _validate_binary_url(url: str) -> None:
        """Validate that *url* is safe to download from.

        Raises:
            InstallationError: on scheme != https, missing hostname,
                               or resolved IP falls in internal space.
        """
        parsed = urlparse(url)
        if parsed.scheme != "https":
            raise InstallationError(
                f"binary_url must use HTTPS, got scheme '{parsed.scheme}'"
            )
        hostname = parsed.hostname
        if not hostname:
            raise InstallationError("binary_url missing hostname")
        if Installer._is_internal_address(hostname):
            raise InstallationError(
                f"binary_url resolves to an internal / restricted address: {hostname}"
            )

    @staticmethod
    def _verify_checksum(dest_path: str, tool: MCPTool) -> None:
        """Verify downloaded file size and SHA-256 if the tool declares them.

        Raises:
            InstallationError: on size or SHA-256 mismatch.
        """
        expected_size = getattr(tool, "binary_size", None)
        if expected_size is not None:
            actual_size = os.path.getsize(dest_path)
            if actual_size != expected_size:
                raise InstallationError(
                    f"Download size mismatch: expected {expected_size}, got {actual_size}"
                )

        expected_sha256 = getattr(tool, "binary_sha256", None)
        if expected_sha256:
            h = hashlib.sha256()
            with open(dest_path, "rb") as fh:
                for chunk in iter(lambda: fh.read(65536), b""):
                    h.update(chunk)
            actual_sha256 = h.hexdigest()
            if actual_sha256 != expected_sha256:
                raise InstallationError(
                    f"SHA-256 checksum mismatch: expected {expected_sha256}, got {actual_sha256}"
                )

    class _SafeRedirectHandler(urllib.request.HTTPRedirectHandler):
        """Custom redirect handler that validates every hop."""

        max_redirects = 5
        _redirect_count = 0

        def redirect_request(self, req, fp, code, msg, headers, newurl):
            Installer._SafeRedirectHandler._redirect_count += 1
            if Installer._SafeRedirectHandler._redirect_count > self.max_redirects:
                raise InstallationError(
                    f"Too many redirects (max {self.max_redirects})"
                )
            parsed = urlparse(newurl)
            if parsed.scheme != "https":
                raise InstallationError(
                    f"Redirect to non-HTTPS URL: {newurl}"
                )
            hostname = parsed.hostname
            if not hostname or Installer._is_internal_address(hostname):
                raise InstallationError(
                    f"Redirect to internal / restricted address: {newurl}"
                )
            return super().redirect_request(req, fp, code, msg, headers, newurl)

    def __init__(self, install_dir: Optional[str] = None) -> None:
        self.install_dir = install_dir or str(DEFAULT_DATA_DIR / "installed")
        if not os.path.isabs(self.install_dir):
            raise ValueError(f"install_dir must be an absolute path: {self.install_dir}")
        self.log_dir = os.path.join(DEFAULT_DATA_DIR, "logs")
        self.registry = Registry()

        self._secure_makedirs(self.install_dir)
        self._secure_makedirs(self.log_dir)

    # ------------------------------------------------------------------
    # Security helpers
    # ------------------------------------------------------------------

    def _validate_tool_name(self, tool_name: str) -> None:
        """Validate tool_name to prevent path traversal attacks.

        Only allows alphanumeric characters, hyphens, and underscores.
        """
        if not tool_name or not re.match(r'^[a-zA-Z0-9_-]+$', tool_name):
            raise ValueError(
                f"Invalid tool_name '{tool_name}': only alphanumeric, "
                "hyphen and underscore characters are allowed"
            )

    def _validate_path_in_install_dir(self, path: str) -> None:
        """Validate that a resolved path is within the install_dir.

        Raises ValueError if the resolved path escapes the install_dir.
        """
        resolved = Path(path).resolve()
        base = Path(self.install_dir).resolve()
        # Ensure the resolved path starts with base + separator to prevent
        # prefix attacks (e.g., /install_dir_evilsuffix)
        if not str(resolved).startswith(str(base) + os.sep):
            raise ValueError(
                f"Path '{path}' is outside install directory '{self.install_dir}'"
            )

    def _secure_makedirs(self, path: str) -> None:
        """Create directory with strict 0o700 permissions.

        Also ensures existing directories have correct permissions.
        """
        os.makedirs(path, mode=0o700, exist_ok=True)
        if os.path.exists(path):
            current_mode = stat.S_IMODE(os.stat(path).st_mode)
            if current_mode != 0o700:
                os.chmod(path, 0o700)

    def _is_valid_tool_name(self, tool_name: str) -> bool:
        """Validate tool name against whitelist to prevent path traversal."""
        return bool(re.match(r"^[a-zA-Z0-9_-]+$", tool_name))

    def _is_valid_package_name(self, package: str) -> bool:
        """Validate package name to prevent option injection.

        Must not start with '-' and must only contain safe characters.
        """
        if not package or package.startswith("-"):
            return False
        return bool(re.match(r"^[a-zA-Z0-9_.@-]+$", package))

    def _is_valid_command_arg(self, arg: str) -> bool:
        """Validate a command argument to prevent shell injection.

        Allowed characters: alphanumeric, dot, underscore, slash,
        colon, at-sign, and hyphen.
        """
        if not arg:
            return False
        return bool(re.match(r"^[a-zA-Z0-9_.\/:@-]+$", arg))

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def install(
        self,
        tool_name: str,
        method: Optional[str] = None,
    ) -> InstallResult:
        """Install an MCP tool.

        Steps
        -----
        1. Look up the tool in the registry.
        2. Determine the install method (registry default or user override).
        3. Check host prerequisites.
        4. Dispatch to the specialised installer.
        5. Verify the installation.
        6. Mark the tool as installed in the registry.
        7. Return an ``InstallResult``.

        If any step fails the installer attempts to roll back partial changes.
        """
        # Validate tool_name before any path construction to prevent path traversal
        try:
            self._validate_tool_name(tool_name)
        except ValueError as exc:
            msg = str(exc)
            logger.error(msg)
            return InstallResult(
                success=False,
                tool_name=tool_name,
                message=msg,
                errors=[msg],
            )

        start_time = time.time()
        errors: List[str] = []

        # 1. Registry lookup
        try:
            tool = self.registry.get_tool(tool_name)
        except KeyError as exc:
            tool = None
        if tool is None:
            msg = f"Tool '{tool_name}' not found in registry"
            logger.error(msg)
            return InstallResult(
                success=False,
                tool_name=tool_name,
                message=msg,
                errors=[msg],
            )

        # 2. Determine method
        chosen_method = method or self._detect_install_method(tool)
        if chosen_method not in INSTALL_TYPES:
            msg = (
                f"Unsupported install method '{chosen_method}' for '{tool_name}'. "
                f"Supported: {', '.join(INSTALL_TYPES)}"
            )
            logger.error(msg)
            return InstallResult(
                success=False,
                tool_name=tool_name,
                message=msg,
                install_method=chosen_method,
                errors=[msg],
            )

        target_dir = os.path.join(self.install_dir, tool_name)

        # 3. Prerequisite check
        if not self._check_prerequisites(chosen_method):
            msg = f"Prerequisites not met for method '{chosen_method}'"
            logger.error(msg)
            return InstallResult(
                success=False,
                tool_name=tool_name,
                message=msg,
                install_method=chosen_method,
                errors=[msg],
            )

        # 4. Dispatch installer
        installer_fn = getattr(self, f"_install_{chosen_method}")
        try:
            result = installer_fn(tool, target_dir)
            result.install_method = chosen_method
        except BaseException:
            self._cleanup_on_failure(tool_name, target_dir, tool)
            raise

        if not result.success:
            self._cleanup_on_failure(tool_name, target_dir, tool)
            return result

        # 5. Verify
        if not self.verify_installation(tool_name):
            msg = f"Installation verification failed for '{tool_name}'"
            logger.error(msg)
            errors.append(msg)
            self._cleanup_on_failure(tool_name, target_dir, tool)
            return InstallResult(
                success=False,
                tool_name=tool_name,
                message=msg,
                install_method=chosen_method,
                install_path=target_dir,
                errors=errors,
            )

        # 6. Mark installed
        try:
            self.registry.mark_installed(tool_name, target_dir, chosen_method)
        except OSError as exc:
            msg = f"Failed to mark '{tool_name}' as installed: {exc}"
            logger.error(msg)
            errors.append(msg)
            self._cleanup_on_failure(tool_name, target_dir, tool)
            return InstallResult(
                success=False,
                tool_name=tool_name,
                message=msg,
                install_method=chosen_method,
                install_path=target_dir,
                errors=errors,
            )

        elapsed = time.time() - start_time
        msg = (
            f"Successfully installed '{tool_name}' via {chosen_method} "
            f"in {elapsed:.1f}s at {target_dir}"
        )
        logger.info(msg)
        return InstallResult(
            success=True,
            tool_name=tool_name,
            message=msg,
            install_method=chosen_method,
            install_path=target_dir,
        )

    def uninstall(self, tool_name: str, purge: bool = False) -> InstallResult:
        """Uninstall an MCP tool.

        Parameters
        ----------
        tool_name:
            Name of the tool to remove.
        purge:
            If ``True``, also delete logs and registry metadata.
        """
        install_path = self.get_install_path(tool_name)
        if install_path is None:
            msg = f"Tool '{tool_name}' is not installed"
            logger.warning(msg)
            return InstallResult(
                success=False,
                tool_name=tool_name,
                message=msg,
                errors=[msg],
            )

        errors: List[str] = []

        # Remove installation directory (with path boundary validation)
        try:
            self._validate_path_in_install_dir(install_path)
            if os.path.isdir(install_path):
                shutil.rmtree(install_path)
                logger.info("Removed installation directory: %s", install_path)
        except ValueError as exc:
            msg = str(exc)
            logger.error(msg)
            errors.append(msg)
        except OSError as exc:
            msg = f"Failed to remove directory {install_path}: {exc}"
            logger.error(msg)
            errors.append(msg)

        # Optional: purge logs
        if purge:
            log_path = self._log_path(tool_name)
            try:
                if os.path.exists(log_path):
                    os.remove(log_path)
                    logger.info("Removed install log: %s", log_path)
            except OSError as exc:
                msg = f"Failed to remove log {log_path}: {exc}"
                logger.error(msg)
                errors.append(msg)

        # Update registry
        try:
            self.registry.mark_uninstalled(tool_name)
        except OSError as exc:
            msg = f"Failed to update registry for '{tool_name}': {exc}"
            logger.error(msg)
            errors.append(msg)

        if errors:
            return InstallResult(
                success=False,
                tool_name=tool_name,
                message=f"Uninstall of '{tool_name}' completed with errors",
                install_path=install_path,
                errors=errors,
            )

        msg = f"Successfully uninstalled '{tool_name}'"
        logger.info(msg)
        return InstallResult(
            success=True,
            tool_name=tool_name,
            message=msg,
        )

    def is_installed(self, tool_name: str) -> bool:
        """Check if a tool is installed."""
        return self.registry.is_installed(tool_name)

    def get_install_path(self, tool_name: str) -> Optional[str]:
        """Get installation directory of a tool."""
        return self.registry.get_install_path(tool_name)

    def list_installed(self) -> List[str]:
        """List all installed tool names."""
        return self.registry.list_installed()

    def update(self, tool_name: str) -> InstallResult:
        """Update an installed tool to the latest version using atomic swap."""
        if not self.is_installed(tool_name):
            msg = f"Tool '{tool_name}' is not installed; cannot update"
            logger.warning(msg)
            return InstallResult(
                success=False,
                tool_name=tool_name,
                message=msg,
                errors=[msg],
            )

        install_path = self.get_install_path(tool_name)
        method = self.registry.get_install_method(tool_name)
        if not install_path or not method:
            msg = f"Cannot determine install path or method for '{tool_name}'"
            logger.error(msg)
            return InstallResult(
                success=False,
                tool_name=tool_name,
                message=msg,
                errors=[msg],
            )

        try:
            self._validate_path_in_install_dir(install_path)
        except ValueError as exc:
            msg = f"Security check failed for '{tool_name}': {exc}"
            logger.error(msg)
            return InstallResult(
                success=False,
                tool_name=tool_name,
                message=msg,
                errors=[msg],
            )

        try:
            tool = self.registry.get_tool(tool_name)
        except KeyError:
            tool = None

        old_path = install_path + ".old"
        try:
            # Remove any stale old directory from a previous failed update
            if os.path.isdir(old_path):
                self._validate_path_in_install_dir(old_path)
                shutil.rmtree(old_path)

            # Atomically move current installation to old_path
            os.rename(install_path, old_path)

            # Install new version (will use the original install_path)
            result = self.install(tool_name, method=method)
            if result.success:
                # New version succeeded, clean up old version
                try:
                    self._validate_path_in_install_dir(old_path)
                    shutil.rmtree(old_path)
                except ValueError as exc:
                    logger.warning("Security check failed for old path of '%s': %s", tool_name, exc)
                except OSError as exc:
                    logger.warning("Failed to remove old version of '%s': %s", tool_name, exc)
                return result

            # New version failed — rollback
            msg = f"Update failed for '{tool_name}': {result.message}"
            logger.error(msg)

            # Clean up any partial new installation
            self._cleanup_on_failure(tool_name, install_path, tool)

            # Restore old version
            if os.path.isdir(old_path):
                if os.path.isdir(install_path):
                    self._validate_path_in_install_dir(install_path)
                    shutil.rmtree(install_path)
                os.rename(old_path, install_path)
                try:
                    self.registry.mark_installed(tool_name, install_path, method)
                except OSError as exc:
                    logger.error("Failed to restore registry for '%s': %s", tool_name, exc)
                    return InstallResult(
                        success=False,
                        tool_name=tool_name,
                        message=f"Update failed and registry restore failed: {exc}",
                        errors=result.errors + [str(exc)],
                    )

            return InstallResult(
                success=False,
                tool_name=tool_name,
                message=f"Update failed, old version restored: {result.message}",
                install_path=install_path,
                errors=result.errors,
            )

        except OSError as exc:
            msg = f"Failed to prepare update for '{tool_name}': {exc}"
            logger.error(msg)
            return InstallResult(
                success=False,
                tool_name=tool_name,
                message=msg,
                errors=[msg],
            )

    def verify_installation(self, tool_name: str) -> bool:
        """Verify a tool is properly installed and working."""
        if not self.is_installed(tool_name):
            return False

        install_path = self.get_install_path(tool_name)
        if install_path is None or not os.path.exists(install_path):
            return False

        method = self.registry.get_install_method(tool_name)
        verify_fn = getattr(self, f"_verify_{method}_installation", None)
        if verify_fn is None:
            # Generic fallback: directory must be non-empty
            return len(os.listdir(install_path)) > 0

        return verify_fn(tool_name, install_path)

    def get_install_log(self, tool_name: str) -> Optional[str]:
        """Get installation log for a tool."""
        log_path = self._log_path(tool_name)
        if not os.path.exists(log_path):
            return None
        try:
            with open(log_path, "r", encoding="utf-8") as fh:
                return fh.read()
        except OSError as exc:
            logger.error("Failed to read log for %s: %s", tool_name, exc)
            return None

    # ------------------------------------------------------------------
    # Install methods
    # ------------------------------------------------------------------

    def _install_npm(self, tool: MCPTool, target_dir: str) -> InstallResult:
        """Install an MCP tool via npm."""
        tool_name = tool.name
        package = getattr(tool, "npm_package", None) or tool_name
        errors: List[str] = []

        self._write_log(tool_name, f"[npm] Installing package: {package}\n")

        # Validate package name to prevent option injection (e.g. --nodedir=/tmp/evil)
        if not self._is_valid_package_name(package):
            msg = f"Invalid npm package name '{package}' for '{tool_name}'"
            return InstallResult(
                success=False,
                tool_name=tool_name,
                message=msg,
                errors=[msg],
            )

        env = os.environ.copy()
        env["NPM_CONFIG_PREFIX"] = target_dir
        env["PATH"] = os.path.join(target_dir, "bin") + os.pathsep + env.get("PATH", "")

        self._secure_makedirs(target_dir)

        # npm install --prefix <target_dir> -- <package>
        # The -- terminator prevents the package from being parsed as an option
        cmd = ["npm", "install", "--prefix", target_dir, "--", package]
        returncode, stdout, stderr = self._run_command(
            cmd,
            cwd=target_dir,
            env=env,
            timeout=300,
        )

        self._write_log(tool_name, stdout, stderr)

        if returncode != 0:
            msg = f"npm install failed for '{tool_name}' (exit {returncode})"
            errors.append(msg)
            if stderr:
                errors.append(stderr.strip())
            return InstallResult(
                success=False,
                tool_name=tool_name,
                message=msg,
                install_path=target_dir,
                errors=errors,
            )

        return InstallResult(
            success=True,
            tool_name=tool_name,
            message=f"npm install succeeded for '{tool_name}'",
            install_path=target_dir,
        )

    def _install_pip(self, tool: MCPTool, target_dir: str) -> InstallResult:
        """Install an MCP tool via pip."""
        tool_name = tool.name
        package = getattr(tool, "pip_package", None) or tool_name
        editable = getattr(tool, "pip_editable", False)
        errors: List[str] = []

        self._write_log(tool_name, f"[pip] Installing package: {package}\n")

        # Validate package name to prevent option injection
        if not self._is_valid_package_name(package):
            msg = f"Invalid pip package name '{package}' for '{tool_name}'"
            return InstallResult(
                success=False,
                tool_name=tool_name,
                message=msg,
                errors=[msg],
            )

        env = os.environ.copy()
        env["PIP_TARGET"] = target_dir
        env["PYTHONPATH"] = target_dir + os.pathsep + env.get("PYTHONPATH", "")

        self._secure_makedirs(target_dir)

        if editable:
            # In editable mode, package is the argument to -e.
            # We cannot insert -- between -e and its argument,
            # so we rely on package name validation (already checked above).
            cmd = ["pip", "install", "-e", package, "--target", target_dir]
        else:
            # Place -- before the package so it cannot be parsed as an option
            cmd = ["pip", "install", "--target", target_dir, "--", package]

        returncode, stdout, stderr = self._run_command(
            cmd,
            env=env,
            timeout=300,
        )

        self._write_log(tool_name, stdout, stderr)

        if returncode != 0:
            msg = f"pip install failed for '{tool_name}' (exit {returncode})"
            errors.append(msg)
            if stderr:
                errors.append(stderr.strip())
            return InstallResult(
                success=False,
                tool_name=tool_name,
                message=msg,
                install_path=target_dir,
                errors=errors,
            )

        return InstallResult(
            success=True,
            tool_name=tool_name,
            message=f"pip install succeeded for '{tool_name}'",
            install_path=target_dir,
        )

    def _install_docker(self, tool: MCPTool, target_dir: str) -> InstallResult:
        """Install an MCP tool via Docker (pull image + generate run script)."""
        tool_name = tool.name
        image = getattr(tool, "docker_image", None) or tool_name
        errors: List[str] = []

        self._write_log(tool_name, f"[docker] Pulling image: {image}\n")

        self._secure_makedirs(target_dir)

        # Pull image
        cmd = ["docker", "pull", image]
        returncode, stdout, stderr = self._run_command(
            cmd,
            timeout=600,
        )
        self._write_log(tool_name, stdout, stderr)

        if returncode != 0:
            msg = f"docker pull failed for '{tool_name}' (exit {returncode})"
            errors.append(msg)
            if stderr:
                errors.append(stderr.strip())
            return InstallResult(
                success=False,
                tool_name=tool_name,
                message=msg,
                install_path=target_dir,
                errors=errors,
            )

        # Write a helper run script so the tool can be started later
        run_script = os.path.join(target_dir, "run.sh")
        try:
            # Atomic creation with restrictive permissions to prevent TOCTOU
            fd = os.open(run_script, os.O_CREAT | os.O_WRONLY | os.O_TRUNC, 0o700)
            with os.fdopen(fd, "w", encoding="utf-8") as fh:
                fh.write("#!/bin/sh\n")
                fh.write(f"docker run --rm -it {shlex.quote(image)} \"$@\"\n")
        except OSError as exc:
            msg = f"Failed to write docker run script for '{tool_name}': {exc}"
            errors.append(msg)
            return InstallResult(
                success=False,
                tool_name=tool_name,
                message=msg,
                install_path=target_dir,
                errors=errors,
            )

        return InstallResult(
            success=True,
            tool_name=tool_name,
            message=f"Docker image '{image}' pulled for '{tool_name}'",
            install_path=target_dir,
        )

    def _install_git(self, tool: MCPTool, target_dir: str) -> InstallResult:
        """Install an MCP tool by cloning a Git repository."""
        tool_name = tool.name
        repo_url = getattr(tool, "git_repo", None)
        if not repo_url:
            msg = f"No git_repo defined for '{tool_name}'"
            return InstallResult(
                success=False,
                tool_name=tool_name,
                message=msg,
                errors=[msg],
            )

        errors: List[str] = []
        self._write_log(tool_name, f"[git] Cloning repo: {repo_url}\n")

        # Clone into target_dir with hooks disabled to prevent arbitrary code execution
        # Use -- to prevent repo_url from being parsed as a git option
        cmd = ["git", "-c", "core.hooksPath=/dev/null", "clone", "--depth", "1", "--", repo_url, target_dir]
        returncode, stdout, stderr = self._run_command(
            cmd,
            timeout=300,
        )
        self._write_log(tool_name, stdout, stderr)

        if returncode != 0:
            msg = f"git clone failed for '{tool_name}' (exit {returncode})"
            errors.append(msg)
            if stderr:
                errors.append(stderr.strip())
            return InstallResult(
                success=False,
                tool_name=tool_name,
                message=msg,
                install_path=target_dir,
                errors=errors,
            )

        # Run optional post-clone install command
        install_cmd = getattr(tool, "install_command", None)
        if install_cmd:
            # STRICT: Reject string-type install_command entirely.
            # Only list-type is accepted to prevent command injection via .split().
            if isinstance(install_cmd, str):
                msg = (
                    f"install_command must be a list for '{tool_name}', "
                    f"string format is not supported"
                )
                return InstallResult(
                    success=False,
                    tool_name=tool_name,
                    message=msg,
                    errors=[msg],
                )
            if not isinstance(install_cmd, list) or not all(
                isinstance(a, str) for a in install_cmd
            ):
                msg = (
                    f"install_command must be a list of strings for "
                    f"'{tool_name}'"
                )
                return InstallResult(
                    success=False,
                    tool_name=tool_name,
                    message=msg,
                    errors=[msg],
                )
            # Validate each argument against whitelist
            for arg in install_cmd:
                if not self._is_valid_command_arg(arg):
                    msg = (
                        f"install_command contains illegal characters in "
                        f"argument: {arg}"
                    )
                    return InstallResult(
                        success=False,
                        tool_name=tool_name,
                        message=msg,
                        errors=[msg],
                    )
            self._write_log(
                tool_name, f"[git] Running install command: {install_cmd}\n"
            )
            returncode, stdout, stderr = self._run_command(
                install_cmd,
                cwd=target_dir,
                timeout=300,
            )
            self._write_log(tool_name, stdout, stderr)
            if returncode != 0:
                msg = (
                    f"Post-clone install command failed for '{tool_name}' "
                    f"(exit {returncode})"
                )
                errors.append(msg)
                if stderr:
                    errors.append(stderr.strip())
                return InstallResult(
                    success=False,
                    tool_name=tool_name,
                    message=msg,
                    install_path=target_dir,
                    errors=errors,
                )

        return InstallResult(
            success=True,
            tool_name=tool_name,
            message=f"git clone succeeded for '{tool_name}'",
            install_path=target_dir,
        )

    def _install_binary(self, tool: MCPTool, target_dir: str) -> InstallResult:
        """Download and install a binary from a URL."""
        tool_name = tool.name
        binary_url = getattr(tool, "binary_url", None)
        if not binary_url:
            msg = f"No binary_url defined for '{tool_name}'"
            return InstallResult(
                success=False,
                tool_name=tool_name,
                message=msg,
                errors=[msg],
            )

        errors: List[str] = []

        # --- Security validation ------------------------------------------
        try:
            self._validate_binary_url(binary_url)
        except InstallationError as exc:
            msg = f"binary_url security validation failed for '{tool_name}': {exc}"
            errors.append(msg)
            return InstallResult(
                success=False,
                tool_name=tool_name,
                message=msg,
                install_path=target_dir,
                errors=errors,
            )

        self._write_log(tool_name, f"[binary] Downloading from: {binary_url}\n")

        self._secure_makedirs(target_dir)

        # Determine filename
        parsed = urlparse(binary_url)
        filename = os.path.basename(parsed.path) or tool_name
        # Sanitize filename to prevent path traversal
        filename = re.sub(r'[^a-zA-Z0-9_.-]', '_', filename)
        if filename in ('.', '..', ''):
            filename = 'download'
        dest_path = os.path.join(target_dir, filename)

        # --- Secure download with chunked read + size limit + redirect ctrl -
        try:
            self._download_binary_to_file(binary_url, dest_path)
        except InstallationError as exc:
            msg = f"Failed to download binary for '{tool_name}': {exc}"
            errors.append(msg)
            return InstallResult(
                success=False,
                tool_name=tool_name,
                message=msg,
                install_path=target_dir,
                errors=errors,
            )
        except urllib.error.URLError as exc:
            msg = f"Failed to download binary for '{tool_name}': {exc}"
            errors.append(msg)
            return InstallResult(
                success=False,
                tool_name=tool_name,
                message=msg,
                install_path=target_dir,
                errors=errors,
            )
        except Exception as exc:  # pragma: no cover
            msg = f"Unexpected error downloading binary for '{tool_name}': {exc}"
            errors.append(msg)
            return InstallResult(
                success=False,
                tool_name=tool_name,
                message=msg,
                install_path=target_dir,
                errors=errors,
            )

        # --- Integrity verification ---------------------------------------
        try:
            self._verify_checksum(dest_path, tool)
        except InstallationError as exc:
            msg = f"Integrity check failed for '{tool_name}': {exc}"
            errors.append(msg)
            # Remove corrupted file before returning error
            try:
                os.remove(dest_path)
            except OSError:
                pass
            return InstallResult(
                success=False,
                tool_name=tool_name,
                message=msg,
                install_path=target_dir,
                errors=errors,
            )

        # Make executable on Unix-like systems
        if platform.system() != "Windows":
            try:
                os.chmod(dest_path, 0o700)
            except OSError as exc:
                msg = f"Failed to make binary executable for '{tool_name}': {exc}"
                logger.warning(msg)
                return InstallResult(
                    success=False,
                    tool_name=tool_name,
                    message=msg,
                    install_path=target_dir,
                    errors=[msg],
                )

        # Optionally handle archives (zip / tar.gz)
        if filename.endswith(".zip"):
            return self._extract_archive(tool, target_dir, dest_path, "zip")
        if filename.endswith((".tar.gz", ".tgz")):
            return self._extract_archive(tool, target_dir, dest_path, "tar.gz")

        return InstallResult(
            success=True,
            tool_name=tool_name,
            message=f"Binary downloaded for '{tool_name}' to {dest_path}",
            install_path=target_dir,
        )

    def _download_binary_to_file(self, url: str, dest_path: str) -> None:
        """Download *url* to *dest_path* with TLS 1.2+, chunked read, size limit, and safe redirect.

        Raises:
            InstallationError: on security or size violations.
            urllib.error.URLError: on network-level failures.
        """
        # Build TLS 1.2+ context
        ctx = ssl.create_default_context()
        ctx.minimum_version = ssl.TLSVersion.TLSv1_2

        # Reset redirect counter for this download
        Installer._SafeRedirectHandler._redirect_count = 0
        opener = urllib.request.build_opener(Installer._SafeRedirectHandler())

        req = urllib.request.Request(
            url,
            headers={"User-Agent": "mcp-hub-installer/1.0"},
        )

        with opener.open(req, timeout=self.DOWNLOAD_TIMEOUT) as response:
            # Atomic creation with restrictive permissions
            fd = os.open(dest_path, os.O_CREAT | os.O_WRONLY | os.O_TRUNC, 0o600)
            with os.fdopen(fd, "wb") as out_file:
                total = 0
                while True:
                    chunk = response.read(self.CHUNK_SIZE)
                    if not chunk:
                        break
                    total += len(chunk)
                    if total > self.MAX_DOWNLOAD_SIZE:
                        raise InstallationError(
                            f"Download exceeded maximum allowed size "
                            f"({self.MAX_DOWNLOAD_SIZE} bytes = 500 MB). "
                            f"Received so far: {total} bytes"
                        )
                    out_file.write(chunk)

    # ------------------------------------------------------------------
    # Verification helpers
    # ------------------------------------------------------------------

    def _verify_npm_installation(self, tool_name: str, install_path: str) -> bool:
        """Verify npm installation by checking node_modules exists."""
        node_modules = os.path.join(install_path, "node_modules")
        return os.path.isdir(node_modules) and len(os.listdir(node_modules)) > 0

    def _verify_pip_installation(self, tool_name: str, install_path: str) -> bool:
        """Verify pip installation by checking the target directory is non-empty."""
        return os.path.isdir(install_path) and len(os.listdir(install_path)) > 0

    def _verify_docker_installation(self, tool_name: str, install_path: str) -> bool:
        """Verify docker installation by checking run script exists."""
        return os.path.exists(os.path.join(install_path, "run.sh"))

    def _verify_git_installation(self, tool_name: str, install_path: str) -> bool:
        """Verify git installation by checking .git directory exists."""
        git_dir = os.path.join(install_path, ".git")
        return os.path.isdir(git_dir)

    def _verify_binary_installation(self, tool_name: str, install_path: str) -> bool:
        """Verify binary installation by ensuring at least one executable exists."""
        for _, _, files in os.walk(install_path):
            for f in files:
                path = os.path.join(install_path, f)
                if os.access(path, os.X_OK):
                    return True
        return False

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _detect_install_method(self, tool: MCPTool) -> str:
        """Auto-detect the best install method for a tool.

        Priority order:
        1. Explicitly declared method on the tool object.
        2. npm if npm_package exists.
        3. pip if pip_package exists.
        4. docker if docker_image exists.
        5. git if git_repo exists.
        6. binary if binary_url exists.
        7. Fall back to 'npm' ( safest default ).
        """
        declared = getattr(tool, "preferred_install_method", None)
        if declared and declared in INSTALL_TYPES:
            return declared

        if getattr(tool, "npm_package", None):
            return "npm"
        if getattr(tool, "pip_package", None):
            return "pip"
        if getattr(tool, "docker_image", None):
            return "docker"
        if getattr(tool, "git_repo", None):
            return "git"
        if getattr(tool, "binary_url", None):
            return "binary"

        return "npm"

    def _check_prerequisites(self, method: str) -> bool:
        """Check if the host has the required tools for *method*."""
        if method == "binary":
            # Binary only needs a working Python urllib
            return True

        cmd = self._PREREQ_COMMANDS.get(method)
        if cmd is None:
            return False

        returncode, _, _ = self._run_command(cmd, timeout=10)
        return returncode == 0

    def _run_command(
        self,
        cmd: List[str],
        cwd: Optional[str] = None,
        env: Optional[Dict[str, str]] = None,
        timeout: int = 300,
    ) -> Tuple[int, str, str]:
        """Run a shell command and return (returncode, stdout, stderr)."""
        logger.debug("Running command: %s in cwd=%s timeout=%s", cmd, cwd, timeout)
        try:
            proc = subprocess.run(
                cmd,
                cwd=cwd,
                env=env,
                capture_output=True,
                text=True,
                timeout=timeout,
                check=False,
            )
            return proc.returncode, proc.stdout or "", proc.stderr or ""
        except subprocess.TimeoutExpired as exc:
            stdout = exc.stdout if exc.stdout else ""
            stderr = exc.stderr if exc.stderr else ""
            logger.error("Command timed out after %ss: %s", timeout, cmd)
            return -1, stdout, f"Command timed out after {timeout}s\n{stderr}"
        except FileNotFoundError:
            logger.error("Command not found: %s", cmd[0])
            return -1, "", f"Command not found: {cmd[0]}"
        except (OSError, subprocess.SubprocessError, ValueError) as exc:
            logger.error("Unexpected error running %s: %s", cmd, exc)
            return -1, "", str(exc)

    def _write_log(
        self,
        tool_name: str,
        stdout: str = "",
        stderr: str = "",
    ) -> None:
        """Append output to the per-tool install log.

        Uses atomic file creation with 0o600 permissions to prevent log tampering.
        Sensitive information is not filtered here; callers should sanitize if needed.
        """
        log_path = self._log_path(tool_name)
        timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
        try:
            # Atomic open with restrictive 0o600 permissions (owner read/write only)
            fd = os.open(log_path, os.O_CREAT | os.O_WRONLY | os.O_APPEND, 0o600)
            with os.fdopen(fd, "w", encoding="utf-8") as fh:
                fh.write(f"\n--- {timestamp} ---\n")
                if stdout:
                    fh.write("[stdout]\n")
                    fh.write(stdout)
                    fh.write("\n")
                if stderr:
                    fh.write("[stderr]\n")
                    fh.write(stderr)
                    fh.write("\n")
        except OSError as exc:
            logger.error("Failed to write log for %s: %s", tool_name, exc)

    def _log_path(self, tool_name: str) -> str:
        """Return the filesystem path for a tool's installation log.

        Sanitizes tool_name to prevent path traversal via log file names.
        """
        safe_name = re.sub(r'[^a-zA-Z0-9_-]', '_', tool_name)
        return os.path.join(self.log_dir, f"{safe_name}.install.log")

    def _cleanup_on_failure(
        self, tool_name: str, target_dir: str, tool: Optional[MCPTool] = None
    ) -> None:
        """Remove partially-installed artifacts on failure."""
        logger.info("Rolling back partial installation for '%s' at %s", tool_name, target_dir)

        # Remove target directory
        try:
            self._validate_path_in_install_dir(target_dir)
            if os.path.isdir(target_dir):
                shutil.rmtree(target_dir)
        except ValueError as exc:
            logger.error("Security check failed during rollback for '%s': %s", tool_name, exc)
        except OSError as exc:
            logger.error("Rollback failed for '%s': %s", tool_name, exc)

        # Remove Docker image if applicable
        if tool is not None:
            image = getattr(tool, "docker_image", None)
            if image:
                try:
                    self._run_command(["docker", "rmi", image], timeout=60)
                except OSError as exc:
                    logger.error("Failed to remove Docker image '%s' for '%s': %s", image, tool_name, exc)

        # Remove install log
        log_path = self._log_path(tool_name)
        try:
            if os.path.exists(log_path):
                os.remove(log_path)
        except OSError as exc:
            logger.error("Failed to remove install log for '%s': %s", tool_name, exc)

        # Clear registry record
        try:
            self.registry.mark_uninstalled(tool_name)
        except OSError as exc:
            logger.error("Failed to clear registry for '%s': %s", tool_name, exc)

    def _extract_archive(
        self,
        tool: MCPTool,
        target_dir: str,
        archive_path: str,
        archive_type: str,
    ) -> InstallResult:
        """Extract a downloaded archive with safety checks against Zip/Tar Slip."""
        tool_name = tool.name
        errors: List[str] = []
        self._write_log(tool_name, f"[binary] Extracting {archive_type} archive: {archive_path}\n")

        def _is_safe_path(base: str, target: str) -> bool:
            """Ensure target path is strictly under base directory."""
            abs_base = os.path.abspath(base)
            abs_target = os.path.abspath(target)
            try:
                return os.path.commonpath([abs_base, abs_target]) == abs_base
            except ValueError:
                # Different drives on Windows
                return False

        def _has_path_traversal(name: str) -> bool:
            """Check if path contains '..' components."""
            for part in name.replace("\\", "/").split("/"):
                if part == "..":
                    return True
            return False

        try:
            if archive_type == "zip":
                with zipfile.ZipFile(archive_path, "r") as zf:
                    for member in zf.infolist():
                        # Reject path traversal sequences
                        if _has_path_traversal(member.filename):
                            raise InstallationError(
                                f"Path traversal in archive: {member.filename}"
                            )
                        # Reject absolute paths
                        if os.path.isabs(member.filename):
                            raise InstallationError(
                                f"Absolute path in archive: {member.filename}"
                            )
                        dest = os.path.join(target_dir, member.filename)
                        # Validate destination is strictly under target_dir
                        if not _is_safe_path(target_dir, dest):
                            raise InstallationError(
                                f"Zip Slip detected: {member.filename}"
                            )
                        # Reject symlinks (Unix external_attr high 4 bits == 0xA)
                        if (member.external_attr >> 28) == 0xA:
                            raise InstallationError(
                                f"Symlink in archive: {member.filename}"
                            )
                    zf.extractall(target_dir)

            elif archive_type in ("tar.gz", "tgz"):
                with tarfile.open(archive_path, "r:gz") as tf:
                    for member in tf.getmembers():
                        # Reject path traversal sequences
                        if _has_path_traversal(member.name):
                            raise InstallationError(
                                f"Path traversal in archive: {member.name}"
                            )
                        # Reject absolute paths
                        if os.path.isabs(member.name):
                            raise InstallationError(
                                f"Absolute path in archive: {member.name}"
                            )
                        dest = os.path.join(target_dir, member.name)
                        # Validate destination is strictly under target_dir
                        if not _is_safe_path(target_dir, dest):
                            raise InstallationError(
                                f"Tar Slip detected: {member.name}"
                            )
                        # Reject symlinks and hardlinks
                        if member.issym() or member.islnk():
                            raise InstallationError(
                                f"Link in archive: {member.name}"
                            )
                    tf.extractall(target_dir)

            # Post-extraction validation: ensure all extracted items are within target_dir
            for root, dirs, files in os.walk(target_dir):
                for name in dirs + files:
                    full_path = os.path.join(root, name)
                    # Verify file is within target_dir
                    if not _is_safe_path(target_dir, full_path):
                        raise InstallationError(
                            f"Extracted file outside target directory: {full_path}"
                        )
                    # Reject any symlinks created during extraction
                    if os.path.islink(full_path):
                        link_target = os.readlink(full_path)
                        if os.path.isabs(link_target):
                            raise InstallationError(
                                f"Symlink with absolute target: {full_path} -> {link_target}"
                            )
                        resolved = os.path.join(os.path.dirname(full_path), link_target)
                        if not _is_safe_path(target_dir, resolved):
                            raise InstallationError(
                                f"Symlink points outside target: {full_path} -> {link_target}"
                            )

            # Remove archive after extraction
            os.remove(archive_path)

        except InstallationError as exc:
            msg = f"Security violation in archive for '{tool_name}': {exc}"
            errors.append(msg)
            self._write_log(tool_name, f"[binary] {msg}\n")
            return InstallResult(
                success=False,
                tool_name=tool_name,
                message=msg,
                install_path=target_dir,
                errors=errors,
            )
        except (OSError, zipfile.BadZipFile, tarfile.TarError) as exc:
            msg = f"Failed to extract archive for '{tool_name}': {exc}"
            errors.append(msg)
            return InstallResult(
                success=False,
                tool_name=tool_name,
                message=msg,
                install_path=target_dir,
                errors=errors,
            )

        return InstallResult(
            success=True,
            tool_name=tool_name,
            message=f"Archive extracted for '{tool_name}'",
            install_path=target_dir,
        )
